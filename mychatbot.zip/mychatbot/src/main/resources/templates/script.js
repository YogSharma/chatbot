function sendMessage() {
    const userInput = document.getElementById('user-input').value;
    if (userInput.trim() === '') return;

    appendMessage('You: ' + userInput, 'user-message');

    // AJAX request to the server
    $.post({
        url: '/chatbot',
        data: { userInput: userInput },
        success: function (response) {
            appendMessage('Chatbot: ' + response, 'chatbot-message');
        }
    });

}

function appendMessage(message, messageType) {
    const chatDisplay = document.getElementById('chat-display');
    const newMessage = document.createElement('div');
    newMessage.textContent = message;
    newMessage.classList.add('message', messageType);
    chatDisplay.appendChild(newMessage);

    // Scroll to the bottom to show the latest message
    chatDisplay.scrollTop = chatDisplay.scrollHeight;
}
