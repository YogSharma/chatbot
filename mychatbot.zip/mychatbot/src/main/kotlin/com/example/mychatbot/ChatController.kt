package com.example.mychatbot

//Group Members
//SHARMA YOG PRASAD	M23W0226
//RANA SURESH		M23W0279
//MAHAT ROSHANI		M23W0284

import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.*

@Controller
@RequestMapping("/chat")
class ChatController(private val chatService: ChatService) {

    @GetMapping
    fun getChat(model: Model): String {
        model.addAttribute("messages", chatService.getMessages())
        return "chat"
    }

    @PostMapping("/send")
    @ResponseBody
    fun sendMessage(@RequestBody message: Message) {
        chatService.addMessage(message)
    }
}
