package com.example.mychatbot

//Group Members
//SHARMA YOG PRASAD	M23W0226
//RANA SURESH		M23W0279
//MAHAT ROSHANI		M23W0284

import org.springframework.stereotype.Service

@Service
class ChatService {

    private val messages = mutableListOf<Message>()

    fun getMessages(): List<Message> {
        return messages
    }

    fun addMessage(message: Message) {
        messages.add(message)
    }
}
