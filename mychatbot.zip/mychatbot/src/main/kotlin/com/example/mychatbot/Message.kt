package com.example.mychatbot

//Group Members
//SHARMA YOG PRASAD	M23W0226
//RANA SURESH		M23W0279
//MAHAT ROSHANI		M23W0284

data class Message(
    val sender: String, val content: String
)
